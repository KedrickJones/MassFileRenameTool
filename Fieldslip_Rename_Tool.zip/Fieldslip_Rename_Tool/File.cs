﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Fieldslip_Rename_Tool
{
    internal class File
    {
        public File(string _fullPath)
        {
            fullPath = _fullPath;
        }
        public string fullPath { get; set; }

        public string GetExtension ()
        {
            string[] splitPath = this.ToString().Split('.');
            return splitPath[splitPath.Length - 1];
        }
        public string GetName_NoExtension()
        {
            string[] splitPath = this.ToString().Split('.');
            string name = "";
            for(int i = 0; i < splitPath.Length - 1; i++)
            {
                name += splitPath[i];
                if (i + 1 != splitPath.Length - 1)
                    name += ".";
            }
            return name;
        }

        public override string ToString()
        {
            string[] splitPath = fullPath.Split('\\');
            return splitPath[splitPath.Length - 1];
        }

        public void openFile()
        {
            using Process fileopener = new Process();

            fileopener.StartInfo.FileName = "explorer";
            fileopener.StartInfo.Arguments = "\"" + fullPath + "\"";
            fileopener.Start();
        }
        public void renameFileTo(string newFileName)
        {
            string newPath = "";

            string[] splitPath = fullPath.Split('\\');

            for (int i = 0; i < splitPath.Length - 1; i++)
                newPath += splitPath[i]+ "\\";

            newPath += newFileName;


            if (fullPath == newPath)//files don't need to be moved if they are already in that spot
                return;

            bool tryMove = true;
            while (tryMove)
            try
            {
                System.IO.File.Move(fullPath, newPath);
                tryMove = false;
            }
            catch
            {
                    splitPath = newPath.Split('.');//split new path to isolate the extension
                    newPath = "";//clear new path
                    for (int i = 0; i < splitPath.Length - 1; i++)
                    {
                        newPath += splitPath[i];
                        if (i + 1 != splitPath.Length - 1)
                            newPath += ".";
                        else
                            newPath += " -  Copy." + splitPath[splitPath.Length - 1];
                    }
            }
            
        }

        public static bool operator > (File left, File right)
        {
            int intLeft, intRight;
            if(left == null || right == null)
                return false;
            else
            {
                if(int.TryParse(left.GetName_NoExtension(), out intLeft)
                    && int.TryParse(right.GetName_NoExtension(), out intRight) )
                    {
                        return intLeft > intRight;
                    }

                return String.Compare(left.ToString(), right.ToString()) > 0;
            }
        }
        public static bool operator < (File left, File right)
        {
            int intLeft, intRight;
            if (left == null || right == null)
                return false;
            else
            {
                if (int.TryParse(left.GetName_NoExtension(), out intLeft)
                    && int.TryParse(right.GetName_NoExtension(), out intRight))
                {
                    return intLeft < intRight;
                }

                return String.Compare(left.ToString(), right.ToString()) < 0;
            }
        }

        public static bool operator <= (File left, File right)
        {
            int intLeft, intRight;
            if (left == null || right == null)
                return false;
            else
            {
                if (int.TryParse(left.GetName_NoExtension(), out intLeft)
                    && int.TryParse(right.GetName_NoExtension(), out intRight))
                {
                    return intLeft <= intRight;
                }

                return String.Compare(left.ToString(), right.ToString()) <= 0;
            }
        }
        public static bool operator >= (File left, File right)
        {
            int intLeft, intRight;
            if (left == null || right == null)
                return false;
            else
            {
                if (int.TryParse(left.GetName_NoExtension(), out intLeft)
                    && int.TryParse(right.GetName_NoExtension(), out intRight))
                {
                    return intLeft >= intRight;
                }

                return String.Compare(left.ToString(), right.ToString()) >= 0;
            }

        }
        
    }
}
