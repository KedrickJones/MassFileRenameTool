﻿namespace Fieldslip_Rename_Tool
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nudRenameQuantity = new System.Windows.Forms.NumericUpDown();
            this.lblRenameQuantity = new System.Windows.Forms.Label();
            this.btn_Renamer = new System.Windows.Forms.Button();
            this.txtExtention = new System.Windows.Forms.TextBox();
            this.lblOldFileName = new System.Windows.Forms.Label();
            this.txtOldFile = new System.Windows.Forms.TextBox();
            this.lblExtention = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPrefix = new System.Windows.Forms.TextBox();
            this.lblPrefix = new System.Windows.Forms.Label();
            this.lblIterator = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chxPrefix = new System.Windows.Forms.CheckBox();
            this.txtIterator = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFileNamePreview = new System.Windows.Forms.TextBox();
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.btnSort = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiOpenFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiOpenFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiFileRange = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNameScheme = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSortDirection = new System.Windows.Forms.ToolStripMenuItem();
            this.sstripFilePath = new System.Windows.Forms.StatusStrip();
            this.slblFilePath = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.nudRenameQuantity)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.sstripFilePath.SuspendLayout();
            this.SuspendLayout();
            // 
            // nudRenameQuantity
            // 
            this.nudRenameQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nudRenameQuantity.Location = new System.Drawing.Point(296, 395);
            this.nudRenameQuantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRenameQuantity.Name = "nudRenameQuantity";
            this.nudRenameQuantity.Size = new System.Drawing.Size(180, 31);
            this.nudRenameQuantity.TabIndex = 5;
            this.nudRenameQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRenameQuantity.ValueChanged += new System.EventHandler(this.nudRenameQuantity_ValueChanged);
            // 
            // lblRenameQuantity
            // 
            this.lblRenameQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRenameQuantity.AutoSize = true;
            this.lblRenameQuantity.Location = new System.Drawing.Point(277, 367);
            this.lblRenameQuantity.Name = "lblRenameQuantity";
            this.lblRenameQuantity.Size = new System.Drawing.Size(215, 25);
            this.lblRenameQuantity.TabIndex = 7;
            this.lblRenameQuantity.Text = "Rename Quantity (Max. 0)";
            // 
            // btn_Renamer
            // 
            this.btn_Renamer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Renamer.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_Renamer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Renamer.Enabled = false;
            this.btn_Renamer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Renamer.Location = new System.Drawing.Point(555, 380);
            this.btn_Renamer.Name = "btn_Renamer";
            this.btn_Renamer.Size = new System.Drawing.Size(112, 59);
            this.btn_Renamer.TabIndex = 8;
            this.btn_Renamer.Text = "Rename Selection";
            this.btn_Renamer.UseVisualStyleBackColor = false;
            this.btn_Renamer.Click += new System.EventHandler(this.btn_Renamer_Click);
            // 
            // txtExtention
            // 
            this.txtExtention.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtExtention.Location = new System.Drawing.Point(298, 71);
            this.txtExtention.Name = "txtExtention";
            this.txtExtention.Size = new System.Drawing.Size(88, 31);
            this.txtExtention.TabIndex = 9;
            this.txtExtention.Text = "Extention";
            this.txtExtention.TextChanged += new System.EventHandler(this.FileName_Changed);
            // 
            // lblOldFileName
            // 
            this.lblOldFileName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOldFileName.AutoSize = true;
            this.lblOldFileName.Location = new System.Drawing.Point(277, 59);
            this.lblOldFileName.Name = "lblOldFileName";
            this.lblOldFileName.Size = new System.Drawing.Size(166, 25);
            this.lblOldFileName.TabIndex = 10;
            this.lblOldFileName.Text = "First File to Rename";
            // 
            // txtOldFile
            // 
            this.txtOldFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOldFile.Location = new System.Drawing.Point(277, 96);
            this.txtOldFile.Name = "txtOldFile";
            this.txtOldFile.ReadOnly = true;
            this.txtOldFile.Size = new System.Drawing.Size(298, 31);
            this.txtOldFile.TabIndex = 11;
            // 
            // lblExtention
            // 
            this.lblExtention.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblExtention.AutoSize = true;
            this.lblExtention.Location = new System.Drawing.Point(298, 41);
            this.lblExtention.Name = "lblExtention";
            this.lblExtention.Size = new System.Drawing.Size(87, 25);
            this.lblExtention.TabIndex = 12;
            this.lblExtention.Text = "Extension";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(283, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 25);
            this.label5.TabIndex = 13;
            this.label5.Text = ".";
            // 
            // txtPrefix
            // 
            this.txtPrefix.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtPrefix.Location = new System.Drawing.Point(16, 72);
            this.txtPrefix.Name = "txtPrefix";
            this.txtPrefix.Size = new System.Drawing.Size(150, 31);
            this.txtPrefix.TabIndex = 14;
            this.txtPrefix.Text = "Prefix";
            this.txtPrefix.TextChanged += new System.EventHandler(this.FileName_Changed);
            // 
            // lblPrefix
            // 
            this.lblPrefix.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPrefix.AutoSize = true;
            this.lblPrefix.Location = new System.Drawing.Point(16, 41);
            this.lblPrefix.Name = "lblPrefix";
            this.lblPrefix.Size = new System.Drawing.Size(55, 25);
            this.lblPrefix.TabIndex = 15;
            this.lblPrefix.Text = "Prefix";
            // 
            // lblIterator
            // 
            this.lblIterator.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblIterator.AutoSize = true;
            this.lblIterator.Location = new System.Drawing.Point(174, 41);
            this.lblIterator.Name = "lblIterator";
            this.lblIterator.Size = new System.Drawing.Size(70, 25);
            this.lblIterator.TabIndex = 16;
            this.lblIterator.Text = "Iterator";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.chxPrefix);
            this.groupBox1.Controls.Add(this.txtIterator);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtFileNamePreview);
            this.groupBox1.Controls.Add(this.txtPrefix);
            this.groupBox1.Controls.Add(this.lblIterator);
            this.groupBox1.Controls.Add(this.lblPrefix);
            this.groupBox1.Controls.Add(this.lblExtention);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtExtention);
            this.groupBox1.Location = new System.Drawing.Point(261, 175);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(406, 154);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "New File Name Scheme";
            // 
            // chxPrefix
            // 
            this.chxPrefix.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.chxPrefix.AutoSize = true;
            this.chxPrefix.Checked = true;
            this.chxPrefix.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chxPrefix.Location = new System.Drawing.Point(77, 45);
            this.chxPrefix.Name = "chxPrefix";
            this.chxPrefix.Size = new System.Drawing.Size(22, 21);
            this.chxPrefix.TabIndex = 20;
            this.chxPrefix.UseVisualStyleBackColor = true;
            this.chxPrefix.CheckedChanged += new System.EventHandler(this.FileName_Changed);
            // 
            // txtIterator
            // 
            this.txtIterator.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtIterator.Location = new System.Drawing.Point(174, 72);
            this.txtIterator.Name = "txtIterator";
            this.txtIterator.Size = new System.Drawing.Size(109, 31);
            this.txtIterator.TabIndex = 18;
            this.txtIterator.Text = "0";
            this.txtIterator.TextChanged += new System.EventHandler(this.FileName_Changed);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 25);
            this.label2.TabIndex = 19;
            // 
            // txtFileNamePreview
            // 
            this.txtFileNamePreview.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFileNamePreview.Location = new System.Drawing.Point(16, 109);
            this.txtFileNamePreview.Name = "txtFileNamePreview";
            this.txtFileNamePreview.ReadOnly = true;
            this.txtFileNamePreview.Size = new System.Drawing.Size(370, 31);
            this.txtFileNamePreview.TabIndex = 18;
            // 
            // lstFiles
            // 
            this.lstFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstFiles.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.HorizontalScrollbar = true;
            this.lstFiles.ItemHeight = 25;
            this.lstFiles.Location = new System.Drawing.Point(16, 47);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(231, 392);
            this.lstFiles.TabIndex = 3;
            this.lstFiles.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lstFiles_DrawItem);
            this.lstFiles.SelectedIndexChanged += new System.EventHandler(this.lstFiles_SelectedIndexChanged);
            // 
            // btnSort
            // 
            this.btnSort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSort.Location = new System.Drawing.Point(207, 405);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(40, 34);
            this.btnSort.TabIndex = 21;
            this.btnSort.Text = "⇑";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOpen.Enabled = false;
            this.btnOpen.Location = new System.Drawing.Point(581, 96);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(66, 34);
            this.btnOpen.TabIndex = 22;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpenSelectedFile_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(679, 33);
            this.menuStrip1.TabIndex = 23;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFolderToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openFolderToolStripMenuItem
            // 
            this.openFolderToolStripMenuItem.Name = "openFolderToolStripMenuItem";
            this.openFolderToolStripMenuItem.Size = new System.Drawing.Size(213, 34);
            this.openFolderToolStripMenuItem.Text = "Open Folder";
            this.openFolderToolStripMenuItem.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(213, 34);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiOpenFile,
            this.tsmiOpenFolder,
            this.tsmiFileRange,
            this.tsmiNameScheme,
            this.tsmiSortDirection});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(65, 29);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // tsmiOpenFile
            // 
            this.tsmiOpenFile.Name = "tsmiOpenFile";
            this.tsmiOpenFile.Size = new System.Drawing.Size(304, 34);
            this.tsmiOpenFile.Text = "Opening a File";
            this.tsmiOpenFile.Click += new System.EventHandler(this.HelpMenu_Click);
            // 
            // tsmiOpenFolder
            // 
            this.tsmiOpenFolder.Name = "tsmiOpenFolder";
            this.tsmiOpenFolder.Size = new System.Drawing.Size(304, 34);
            this.tsmiOpenFolder.Text = "Opening a Folder";
            this.tsmiOpenFolder.Click += new System.EventHandler(this.HelpMenu_Click);
            // 
            // tsmiFileRange
            // 
            this.tsmiFileRange.Name = "tsmiFileRange";
            this.tsmiFileRange.Size = new System.Drawing.Size(304, 34);
            this.tsmiFileRange.Text = "Selecting File Range";
            this.tsmiFileRange.Click += new System.EventHandler(this.HelpMenu_Click);
            // 
            // tsmiNameScheme
            // 
            this.tsmiNameScheme.Name = "tsmiNameScheme";
            this.tsmiNameScheme.Size = new System.Drawing.Size(304, 34);
            this.tsmiNameScheme.Text = "New File Name Scheme";
            this.tsmiNameScheme.Click += new System.EventHandler(this.HelpMenu_Click);
            // 
            // tsmiSortDirection
            // 
            this.tsmiSortDirection.Name = "tsmiSortDirection";
            this.tsmiSortDirection.Size = new System.Drawing.Size(304, 34);
            this.tsmiSortDirection.Text = "Changing Sort Direction";
            this.tsmiSortDirection.Click += new System.EventHandler(this.HelpMenu_Click);
            // 
            // sstripFilePath
            // 
            this.sstripFilePath.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.sstripFilePath.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.slblFilePath});
            this.sstripFilePath.Location = new System.Drawing.Point(0, 460);
            this.sstripFilePath.Name = "sstripFilePath";
            this.sstripFilePath.Size = new System.Drawing.Size(679, 22);
            this.sstripFilePath.TabIndex = 24;
            this.sstripFilePath.Text = "statusStrip1";
            // 
            // slblFilePath
            // 
            this.slblFilePath.Name = "slblFilePath";
            this.slblFilePath.Size = new System.Drawing.Size(0, 15);
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 482);
            this.Controls.Add(this.sstripFilePath);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtOldFile);
            this.Controls.Add(this.lblOldFileName);
            this.Controls.Add(this.btn_Renamer);
            this.Controls.Add(this.lblRenameQuantity);
            this.Controls.Add(this.nudRenameQuantity);
            this.Controls.Add(this.lstFiles);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Fieldslip Renamer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.FilePath_DragDrop);
            this.DragOver += new System.Windows.Forms.DragEventHandler(this.FilePath_DragOver);
            ((System.ComponentModel.ISupportInitialize)(this.nudRenameQuantity)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.sstripFilePath.ResumeLayout(false);
            this.sstripFilePath.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private NumericUpDown nudRenameQuantity;
        private Label label3;
        private Button btn_Renamer;
        private TextBox txtExtention;
        private Label lblOldFileName;
        private TextBox txtOldFile;
        private Label lblExtention;
        private Label label5;
        private TextBox txtPrefix;
        private Label lblPrefix;
        private Label lblIterator;
        private GroupBox groupBox1;
        private Label label2;
        private TextBox txtFileNamePreview;
        private TextBox txtIterator;
        private CheckBox chxPrefix;
        private ListBox lstFiles;
        private Label lblRenameQuantity;
        private Button btnSort;
        private Button btnOpen;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem openFolderToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem tsmiOpenFile;
        private ToolStripMenuItem tsmiOpenFolder;
        private ToolStripMenuItem tsmiFileRange;
        private ToolStripMenuItem tsmiNameScheme;
        private ToolStripMenuItem tsmiSortDirection;
        private StatusStrip sstripFilePath;
        private ToolStripStatusLabel slblFilePath;
    }
}