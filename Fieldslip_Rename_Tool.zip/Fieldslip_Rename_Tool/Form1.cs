﻿using System.Text.RegularExpressions;
using System.Drawing;

namespace Fieldslip_Rename_Tool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }


        private static string previousIterator;
        private static DrawItemEventArgs previousDIEA;
        private void Form1_Load(object sender, EventArgs e)
        {
            chxPrefix.Checked = false;
            FileName_Changed(null, null);
            previousIterator = txtIterator.Text;
            lblExtention.Focus();
            slblFilePath.Text = "Drag and Drop a folder anywhere...";
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    string[] files = Directory.GetFiles(fbd.SelectedPath);

                    if (files.Length < 0)
                    {
                        System.Windows.Forms.MessageBox.Show("Files found: " + files.Length.ToString(), "Message");
                    }
                    else
                    {
                        slblFilePath.Text = fbd.SelectedPath;
                        lblExtention.Focus();
                        lstFiles_Refresh();
                    }          
                }
            }
        }
        private void lstFiles_DrawItem(object sender, DrawItemEventArgs e)
        {
            Color pastelGreen = System.Drawing.ColorTranslator.FromHtml("#DEFDE0");
            Color pastelRed = System.Drawing.ColorTranslator.FromHtml("#FDDFDF");
            previousDIEA = e;
            int endPosition = (int)nudRenameQuantity.Value - 1;

            if(endPosition < 0)
                endPosition = 0;

            if (lstFiles.Items.Count > 0)
            {
                //if the item state is selected them change the back color 
                if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                {
                    e = new DrawItemEventArgs(e.Graphics,
                                              e.Font,
                                              e.Bounds,
                                              e.Index,
                                              e.State ^ DrawItemState.Selected,
                                              e.ForeColor,
                                              pastelGreen);//Choose the color
                }

                // Draw the background of the ListBox control for each item.
                e.DrawBackground();
                // Draw the current item text
                e.Graphics.DrawString(lstFiles.Items[e.Index].ToString(), e.Font, Brushes.Black, e.Bounds, StringFormat.GenericDefault);
                // If the ListBox has focus, draw a focus rectangle around the selected item.
                e.DrawFocusRectangle();

                if (e.Index == lstFiles.SelectedIndex + endPosition
                    && lstFiles.SelectedIndex != -1
                    && e.Index != lstFiles.SelectedIndex)
                {
                    e = new DrawItemEventArgs(e.Graphics,
                                              e.Font,
                                              e.Bounds,
                                              e.Index,
                                              e.State,
                                              e.ForeColor,
                                              pastelRed);//Choose the color
                }


                // Draw the background of the ListBox control for each item.
                e.DrawBackground();
                // Draw the current item text
                e.Graphics.DrawString(lstFiles.Items[e.Index].ToString(), e.Font, Brushes.Black, e.Bounds, StringFormat.GenericDefault);
                // If the ListBox has focus, draw a focus rectangle around the selected item.
                e.DrawFocusRectangle();
            }
        }
        private void nudRenameQuantity_ValueChanged(object sender, EventArgs e)
        {
            //NumericUpDown nudSender = sender as NumericUpDown;
            //if(previousDIEA != null && nudRenameQuantity == sender as NumericUpDown)
            //    lstFiles_DrawItem(lstFiles, previousDIEA);
            this.lstFiles.Invalidate();
            FileName_Changed(null, null);
        }

        private void FilePath_DragOver(object sender, DragEventArgs e)
        {
            DragDropEffects effects = DragDropEffects.None;
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var path = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
                if (Directory.Exists(path))
                    effects = DragDropEffects.Copy;
            }

            e.Effect = effects;
            lblExtention.Focus();
        }

        private void FilePath_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = e.Data.GetData(DataFormats.FileDrop) as string[]; // get all files droppeds  
            if (files != null && files.Any())
            {
                slblFilePath.Text = files.First();
                lblExtention.Focus();
                lstFiles_Refresh();
            }
        }

        private void lstFiles_Refresh()
        {
            lstFiles.Items.Clear();
            string[] filePathArr = Directory.GetFiles(slblFilePath.Text);
            File[] fileArr = SortFiles(filePathArr);
           
            foreach (File file in fileArr)
            {
                if(file != null)
                    lstFiles.Items.Add(file);
            }
            if (lstFiles.Items.Count == 0)
            {
                lstFiles.Items.Add("No Files Found :(");
            }
            else
            {
                nudRenameQuantity.Maximum = lstFiles.Items.Count;
                lblRenameQuantity.Text = "Rename Quantity (Max. " + lstFiles.Items.Count.ToString()+ ")";
            }
            

            lblExtention.Focus();
        }

        private File[] SortFiles(string[] strArray)
        {
            File[] files = new File[strArray.Length];
            
            int i = 0;
            foreach (string filePath in strArray)
            {
                File file = new File(filePath);
                if (file.ToString() != "desktop.ini")
                    files[i] = file;
                i++;
            }
            if (files.Length > 0)
                return SortFilesUtility(files, 0, files.Length - 1);
            return files;
        }
            
        private File[] SortFilesUtility(File[] array, int leftIndex, int rightIndex)
        {
            var i = leftIndex;
            var j = rightIndex;
            File pivot = array[leftIndex];
            
            while (i <= j)
            {
                while (array[i] < pivot)
                {
                    i++;
                }

                while (array[j] > pivot)
                {
                    j--;
                }

                if (i <= j)
                {
                    File temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                    i++;
                    j--;
                }
            }

            if (leftIndex < j)
                    SortFilesUtility(array, leftIndex, j);

            if (i < rightIndex)
                    SortFilesUtility(array, i, rightIndex);

            return array;
        }

        
        private void lstFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.lstFiles.Invalidate();

            File selectedFile = lstFiles.SelectedItem as File;

            txtOldFile.Text = selectedFile.ToString();
            txtExtention.Text = selectedFile.GetExtension();

            int countItemsBelowSelected = lstFiles.Items.Count - lstFiles.SelectedIndex;
            nudRenameQuantity.Maximum = countItemsBelowSelected;
            lblRenameQuantity.Text = "Rename Quantity (Max. " + countItemsBelowSelected + ")";


            btn_Renamer.Enabled = true;
            btnOpen.Enabled = true;
        }

        //update the New File Name Preview
        private void FileName_Changed(object sender, EventArgs e)
        {

            if (txtIterator == sender as TextBox) //txtIterator Changed
            {
                bool isNumeric = int.TryParse(txtIterator.Text, out _);

                if (isNumeric || txtIterator.Text == "")
                {
                    previousIterator = txtIterator.Text;
                }
                else
                {
                    txtIterator.Text = previousIterator;
                }

                txtIterator.Focus();
                txtIterator.Select(txtIterator.Text.Length, 0);
            }

            if (chxPrefix.Checked)
            {
                txtPrefix.Enabled = true;
            }
            else if (!chxPrefix.Checked)
            {
                txtPrefix.Enabled = false;
            }

            txtFileNamePreview.Clear(); //clear fileName Preview
            int int_Iterator = 0;//Set default Iterator Value to 0
            int.TryParse(txtIterator.Text, out int_Iterator);//reset value if iterator is a proper int


            int intRenameQuantity = (int)nudRenameQuantity.Value;

            if (txtPrefix.Enabled)
                txtFileNamePreview.Text = txtPrefix.Text;//add Prefix to First File
            txtFileNamePreview.Text += int_Iterator.ToString() + "." + txtExtention.Text;//add iterator and extention
                
            if(intRenameQuantity > 1)
            {
                txtFileNamePreview.Text += " ... ";
                if (txtPrefix.Enabled)
                    txtFileNamePreview.Text += txtPrefix.Text;//add Prefix to First File
                txtFileNamePreview.Text += 
                    (int_Iterator + intRenameQuantity - 1).ToString() //Add iterator + renameQUantity
                    + "." + txtExtention.Text;//add extention
            }
               
        }

        private void btn_Renamer_Click(object sender, EventArgs e)
        {
            if (lstFiles.SelectedIndex == -1)
                return;
            int renameQuantity = (int)nudRenameQuantity.Value;
            int firstIndex = lstFiles.SelectedIndex;
            int lastIndex = firstIndex + renameQuantity - 1;

            File[] filesToRename = new File[renameQuantity];

            for (int i = firstIndex; i <= lastIndex; i++)//Get a list of the old File Paths
            {
                filesToRename[i - firstIndex] = lstFiles.Items[i] as File;
            }

            string prefix = "";
            if(txtPrefix.Enabled)
                prefix = txtPrefix.Text;

            //universal variables of the renaming process
            int nameIterater = 0;
            int.TryParse(txtIterator.Text, out nameIterater);
            string extention = "." + txtExtention.Text;
            string newName = "";
            File file;


            //create a list of new file names the "ToString()" version of File (file name.extension)
            string[] newFileNames = new string[renameQuantity];
            for (int i = firstIndex; i <= lastIndex; i++)//Get a list of the old File Paths
            {
                newFileNames[i - firstIndex] = prefix + nameIterater.ToString() + extention;
                nameIterater++;
            }


            //figure out which direction to rename in;
            bool renameForwards = true;
            int instancesForForwards = 0; int instancesForBackwards = 0;
            for(int fileIndex = 0; fileIndex < renameQuantity; fileIndex++)
            {
                for(int nameIndex = 0; nameIndex < renameQuantity; nameIndex++)
                {
                    if(filesToRename[fileIndex].ToString() == newFileNames[nameIndex])
                    {
                        if(fileIndex > nameIndex)
                        {
                            instancesForBackwards++;
                        }
                        else if (fileIndex < nameIndex)
                        {
                            instancesForForwards++;
                        }
                    }
                }
            }
            if (instancesForForwards < instancesForBackwards)
                renameForwards = false;

            //rename files in the proper direction
            if(renameForwards)
            {
                for (int i = 0; i < filesToRename.Length; i++)
                {
                    file = filesToRename[i];
                    newName = newFileNames[i];
                    file.renameFileTo(newName);
                }
            }
            else
            {
                for (int i = filesToRename.Length - 1; i >= 0; i--)
                {
                    file = filesToRename[i];
                    newName = newFileNames[i];
                    file.renameFileTo(newName);
                }
            }
            lstFiles_Refresh();
            btn_Renamer.Enabled = false;
        }

        private void btnOpenSelectedFile_Click(object sender, EventArgs e)
        {
            if (lstFiles.SelectedItem != null)
            {
                (lstFiles.SelectedItem as File).openFile();
            }
            if(nudRenameQuantity.Value > 1)
            {
                (lstFiles.Items[lstFiles.SelectedIndex + (int)nudRenameQuantity.Value-1] as File).openFile();
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            if (lstFiles.Items.Count > 1)
            {
                File[] files = new File[lstFiles.Items.Count];

                for (int i = 0; i < files.Length; i++)
                {
                    files[i] = lstFiles.Items[i] as File;
                }

                lstFiles.Items.Clear();

                for (int i = files.Length - 1; i >= 0; i--)
                {
                    lstFiles.Items.Add(files[i]);
                }

                if (btnSort.Text == "⇑")
                    btnSort.Text = "⇓";
                else
                    btnSort.Text = "⇑";

                lstFiles.Invalidate();
                btn_Renamer.Enabled = false;
                btnOpen.Enabled = false;
                txtOldFile.Text = "";
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void HelpMenu_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem clickedButton = sender as ToolStripMenuItem;

            if(clickedButton == tsmiOpenFile)
            {
                MessageBox.Show("" +
                    "  You can open a file directly from the Fieldslip Rename Tool." +
                    "\n1) Open a Folder."+
                    "\n2) Select a file from the List Box on the left." +
                    "\n3) Press the Open button to open the selected file in its default application.",
                    "Opening a File");

            }
            else if (clickedButton == tsmiOpenFolder)
            {
                MessageBox.Show(
                    "  You can open a folder one of 2 ways:" +
                    "\nby dragging and dropping it into the application, " +
                    "\nor by clicking \"Open File\" from the Menu Strip, " +
                    "\nand selecting a folder from the File Explorer.", "Opening a Folder");
            }
            else if (clickedButton == tsmiNameScheme)
            {
                MessageBox.Show(
                    "  The Range of Files to be renamed by the program is selected" +
                    "\nby clicking the file from the list that should be first," +
                    "\nand then selecting a number of files to rename with the " +
                    "\nRename Quantity field. You should Notice that two files in" +
                    "\nare now selected. The Green file is the first file to be renamed," +
                    "\nand the Red file is the last file to be renamed. " +
                    "\n" +
                    "\nNOTE: The Files that get renamed are the ones that are visually " +
                    "\nbetween the two selected files on the list, not the ones in-" +
                    "\nbetween those files in the file explorer.", "New File Name Scheme");
                
            }
            else if (clickedButton == tsmiFileRange)
            {
                MessageBox.Show(
                    "  The files you have selected for renaming will be " +
                    "\nrenamed using the New File Name Scheme as a template." +
                    "\nThe text box at the bottom of the new File Name Scheme " +
                    "\nbox shows an example of what these new names will look " +
                    "\nlike.The Iterator Field increments by 1 for each new " +
                    "\nname so that every file name is unique.", "Selecting a File Range");
            }
            else if (clickedButton == tsmiSortDirection)
            {
                MessageBox.Show(
                    "  To change the sort direction of the files on the list, use the" +
                    "\nsquare button in the lower right-hand corner of the list box." +
                    "\n" +
                    "\nNOTE: The sort order of the list DOES impact the way the files" +
                    "\nwill be renamed.", "Changing Sort Direction");
            }
        }
    }
}